import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';
import { Products } from '../products/products.component';

@Component({
  selector: 'app-description',
  templateUrl: './description.component.html',
  styleUrls: ['./description.component.css']
})
export class DescriptionComponent implements OnInit {
  httpClient: any;
  products:Array<Products>=[];

  constructor(private customerService: CustomerService, private route: Router) { }

  ngOnInit():any {
    this.customerService.getProducts().subscribe(
     (products: Products[]) => {
       console.log(products);
       this.products= products;},
             
     (error) =>{
       alert("Something went wrong!!!!!!  Plz try again");
     });
   }
   
}
