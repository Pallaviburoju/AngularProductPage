import { Component, OnInit } from '@angular/core';
import { setTNodeAndViewData } from 'ProductPage/node_modules/@angular/core/src/render3/state';
import { NavigationEnd } from 'ProductPage/node_modules/@angular/router';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';

export class Products
{
  categoryId:number;
  productId:number;
  productName:string;
  productPrice:number;
  productQuantity:number;
  productDescription:string;
  productRating:number;
  productFeedback:string;
  merchantId:number;

  constructor(categoryId:number,productId:number,productName:string,productPrice:number,productQuantity:number,productDescription:string, productRating:number,productFeedback:string,merchantId:number)

  {
    this.categoryId=categoryId;
this.productId=productId;
this.productName=productName;
this.productPrice=productPrice;
this.productQuantity=productQuantity;
this.productDescription=productDescription;
this.productRating=productRating;
this.productFeedback=productFeedback;
this.merchantId=merchantId;

  }
}
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  httpClient: any;
  products:Array<Products>=[];
  isClicked: Boolean=true
  pId:number
  constructor(private customerService: CustomerService, private route: Router) { 
    this.customerService=customerService;
  }

  ngOnInit():any {
   this.customerService.getProducts().subscribe(
    (products: Products[]) => {
      console.log(products);
      this.products= products;},
            
    (error) =>{
      alert("Something went wrong!!!!!!  Plz try again");
    });
  }
  onClick(pId: number) {
    this.pId=pId;
    console.log(this.pId)
    
  }  
}
