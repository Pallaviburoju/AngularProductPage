import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private baseUrl: string = "http://localhost:8009";
  private headers = new HttpHeaders({ 'Content-type': 'application/json' });
  private options = { headers: this.headers }

  constructor(private http: HttpClient, private router: Router) {}
getProducts() {
      // return this.http.get(this.baseUrl + '/getAllCustomers', this.options).pipe(map((response: Response) => response.json().catch(this.errorHandler)));
      return this.http.get(this.baseUrl + '/getAll', this.options);
    
   }
id:number;
   saveData(id:number){
     this.id=this.id;
     return this.id;
   }
}
